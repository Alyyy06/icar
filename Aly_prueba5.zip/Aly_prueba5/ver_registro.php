<?php
include('conexion.php');

// Obtener el ID del registro de la URL
if (isset($_GET['id'])) {
    $idRegistro = $_GET['id'];

    // Función para obtener la información de un registro por ID
    function obtenerRegistroPorID($id) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM registros_icarplus WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // Obtener detalles del registro
    $registro = obtenerRegistroPorID($idRegistro);

    // Verificar si el registro existe
    if (!$registro) {
        echo "Registro no encontrado.";
        exit();
    }

    // Función para obtener la información de un vehículo por matrícula
function obtenerVehiculoPorMatricula($matricula) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM vehiculos_icarplus WHERE matricula = ?");
    $stmt->bind_param("s", $matricula);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Función para obtener la información de un cliente por cédula
function obtenerClientePorCedula($cedula) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM clientes_icarplus WHERE cedula = ?");
    $stmt->bind_param("i", $cedula);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Función para obtener la información de un mecánico por cédula
function obtenerMecanicoPorCedula($cedula) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM mecanicos_icarplus WHERE cedula = ?");
    $stmt->bind_param("i", $cedula);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Función para obtener la información de un repuesto por serial
function obtenerRepuestoPorSerial($serial) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM repuestos_icarplus WHERE serial = ?");
    $stmt->bind_param("s", $serial);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}


    // Obtener información adicional
    $vehiculo = obtenerVehiculoPorMatricula($registro['matricula_vehiculos']);
    $cliente = obtenerClientePorCedula($vehiculo['cedula_cliente']);
    $mecanico = obtenerMecanicoPorCedula($registro['cedula_mecanicos']);
    $repuesto = obtenerRepuestoPorSerial($registro['serial_repuestos']);
} else {
    echo "ID de registro no proporcionado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iCar Plus</title>
    <!-- Incluye los archivos CSS de Materialize -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!-- Agrega tus propios estilos si es necesario -->
</head>
<body>

<!-- Encabezado -->
<nav class="#303f9f #004d40 teal darken-4">
    <div class="nav-wrapper container">
      <a href="#" class="brand-logo left">iCar Plus</a>
      <ul id="nav-mobile" class="right">
        <li><a href="pagina_principal.php">Inicio</a></li>
        <li><a href="cerrar_sesion.php">Cerrar Sesión</a></li>
      </ul>
    </div>
  </nav>

<!-- Contenido -->
<div class="container">
    <h3 class="center-align card-panel #303f9f #004d40 teal darken-4 white-text">Detalles</h3>
<div class="row">
        <div class="col l8 offset-l2 s12">
            <div class="card">
                <div class="card-content">
                    <p class="center"><strong>INFORMACIÓN DEL VEHICULO:</strong></p>
                    <!-- Información del Vehículo -->
                    <p><strong>Matrícula Vehículo:</strong> <?php echo $vehiculo['matricula']; ?></p>
                    <p><strong>Modelo Vehículo:</strong> <?php echo $vehiculo['modelo']; ?></p>
                    <p><strong>Cédula Cliente Vehículo:</strong> <?php echo $cliente['cedula']; ?></p>
                    <p><strong>Foto Vehículo:</strong> </p>
                    <img src="<?php echo $vehiculo['imagen']; ?>" alt="Foto del Vehículo" style="max-width: 200px;"><br>
<br>
                    <p class="center" ><strong>INFORMACIÓN DEL MECÁNICO:</strong></p>
                    <!-- Información del Mecánico -->
                    <p><strong>Nombre Mecánico:</strong> <?php echo $mecanico['nombre'] . ' ' . $mecanico['apellido']; ?></p>
                    <p><strong>Cédula Mecánico:</strong> <?php echo $mecanico['cedula']; ?></p><br>

                    <p class="center"><strong>INFORMACIÓN DEL RESPUESTO:</strong></p>
                    <!-- Información del Repuesto -->
                    <p><strong>Serial Repuestos:</strong> <?php echo $repuesto['serial']; ?></p>
                    <p><strong>Nombre Repuesto:</strong> <?php echo $repuesto['nombre']; ?></p>
                    <p><strong>Cantidad Repuestos:</strong> <?php echo $registro['cantidad_repuestos']; ?></p><br>
                    <p class="center"><strong>Fecha Ingreso:</strong> <?php echo $registro['fecha_ingreso']; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="center">

    <footer class="page-footer #303f9f #004d40 teal darken-4
">
        <div class="footer-copyright">
            <div class="container">
                <p> Alidsabeth Jimenez <br>
                    Todos los derechos son reservados <br>
                    Copyright © 2023</p>
            </div>
            <div></div>
        </div>
    </footer>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="assets\js\init.js"></script>
</body>
</html>
